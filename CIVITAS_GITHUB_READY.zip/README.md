# CIVITAS Safari Prototype

GitHub Pages:
- Source: Deploy from a branch
- Branch: main
- Folder: /(root)

`index.html` MUST remain in the repository root.
